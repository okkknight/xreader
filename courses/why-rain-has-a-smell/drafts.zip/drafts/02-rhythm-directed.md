# Why Does Rain Have a Smell?

有些气味在雨真正落下前就已经到了。今天这篇文章从这个熟悉的反差开始：我们闻到的到底是什么？

**Why Does Rain Have a Smell?** 为什么雨会有气味？标题是一个直接的问题，读完之后，答案会从“雨水本身”转向土地、植物、微生物和空气之间发生的过程。

**People often notice the smell of rain before the first drop reaches the ground.** `before` 把时间关系说得很清楚：第一滴雨还没有落地，人们已经可能察觉到气味。先听这一句的整体反差：**People often notice the smell of rain before the first drop reaches the ground.**

**That familiar scent has a name: petrichor.** `That` 接住前面的雨的气味，`petrichor` 是它的名称。先能认出这个词就够了，不必停下来背拼写。

**The word joins Greek roots for stone and a fluid once linked to the earth.** 这句只需要抓住词源画面：`petrichor` 把“石头”和一种曾与土地联系在一起的液体放进同一个词里。

**It describes a real mixture rather than one single perfume.** `It` 指这个名称所描述的气味，`rather than` 划出关键对比：它是多种成分的真实混合物，不是一瓶单一的“雨香水”。第一段完成了命名，也先拆掉了一个误解。

接下来文章不再解释名字，而是追踪气味怎样进入空气。

**It appears when dry soil, plants, and tiny organisms release compounds into the air.** `It` 仍然指这种气味。干燥土壤、植物和微小生物会把化合物释放进空气，句子里的三个并列来源共同构成起点。

**Rain carries those compounds upward as small droplets hit the ground.** `those compounds` 承接上一句；`as` 表示雨滴撞击地面的同时，雨把这些成分带向上方。重点不是雨制造气味，而是雨提供了移动路径。

**The droplets can burst and make a fine spray.** 雨滴可能破裂，形成细喷雾。句子短，但它是过程中的动作节点。

**That spray gives the scent a route into the air around you.** `That spray` 把前一句的动作收回来：喷雾让地面成分进入你周围的空气。把这四句连着听，先抓一条链：来源、撞击、喷雾、到达鼻子附近。

第三段把镜头推进到一个具体成分。**One important compound is made by soil bacteria.** 这是“其中一种重要成分”，不是全部答案；它由土壤细菌产生。

**It is called geosmin.** `It` 指这个成分，`is called` 是命名结构。`geosmin` 先作为识别词保留下来，不需要现在主动背下来。

**Humans are unusually sensitive to it, even at very low levels.** `sensitive to` 是“对……敏感”，`it` 仍指 geosmin。即使浓度很低，人类也可能察觉到它。

**That sensitivity may explain why a light shower can seem surprisingly noticeable.** `That sensitivity` 承接上句，`may explain why` 保留了“可能解释”的余地。小雨也可能显得气味明显，原因之一就是人类对这种成分很敏感。重听时只抓 `may` 的谨慎语气和 `why` 后面的结果。

另一条来源来自植物。**Another part comes from oils that plants leave on dry surfaces.** `Another part` 说明 petrichor 还有另一部分；植物留在干燥表面的油也参与其中。

**Those oils build up during dry weather.** `build up` 表示逐渐积累。干燥持续得越久，表面留下的东西越多。

**After a long dry spell, the first rain can release more of them at once.** `After` 把久旱放在第一场雨之前，`more of them` 指更多的植物油，`at once` 是一下子释放。这里要听出先后顺序。

**A sudden summer shower may therefore smell stronger than steady rain.** `therefore` 把前面的积累推向结果；突然的夏季阵雨可能比持续的雨闻起来更强。`may` 再次提醒我们这是解释，不是绝对规律。

现在文章从来源转向地点差异。**The smell is not exactly the same in every place.** `not exactly the same` 表示不完全相同，雨的气味没有一张固定配方。

**Temperature changes how quickly compounds move through the air.** 温度会改变这些化合物在空气中移动的速度。`how quickly` 让我们关注移动快慢，而不是把温度简单等同于气味强弱。

**Wind decides whether they reach you or drift away.** `they` 指这些化合物；`whether ... or ...` 给出两种结果：到达你这里，或者飘走。地面释放了成分，不代表你一定闻得到。

**Soil and local plants add their own small signature.** `signature` 在这里是地方特征。土壤和当地植物给同一种天气加上不同的“小签名”。第五段的重点是：气味由地点和当时的空气条件共同决定。

最后回到标题的问题。**So the next time rain seems to have a smell, you are noticing a small weather story.** `the next time` 把解释带回日常经验；你注意到的不是一个孤立的气味，而是一段天气故事。

**The air is carrying evidence of a dry landscape meeting water again.** `evidence of` 是“……的证据”。空气带来的，是干燥土地重新遇到水的证据。

**It is a sensory clue about what was on the ground before the rain began.** `It` 指这种气味，`what was on the ground` 说明它提供了关于下雨前地面状态的感官线索。

**That is why the same weather can feel different in two nearby places.** `That is why` 收束全文：相邻地点的土壤、植物、温度和风不同，所以同样的天气也可能闻起来不同。再连听最后四句，感受文章如何从“闻到气味”回到“地面留下什么”：**So the next time rain seems to have a smell, you are noticing a small weather story. The air is carrying evidence of a dry landscape meeting water again. It is a sensory clue about what was on the ground before the rain began. That is why the same weather can feel different in two nearby places.**

文章没有把 petrichor 讲成一个需要背下来的术语，而是沿着一条过程读完：成分来自哪里，雨滴怎样把它们带进空气，为什么少量 geosmin 也可能明显，以及为什么不同地点的雨有自己的气味。答案回到生活里时，标题的问题也就真正有了画面。
