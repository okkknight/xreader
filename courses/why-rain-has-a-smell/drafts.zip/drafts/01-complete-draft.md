# Why Does Rain Have a Smell?

有些气味很熟悉，却不一定容易说清楚。先读标题：**Why Does Rain Have a Smell?** 为什么雨会有气味？标题用一个很直接的疑问，把我们带进一个生活经验：雨还没真正落下，有时我们已经闻到了它。读完这篇文章，你会知道这种气味不是雨水凭空带来的，而是土地、植物、微生物、雨滴和空气共同留下的结果。

先看第一句：**People often notice the smell of rain before the first drop reaches the ground.** `notice` 是“注意到、察觉到”，`before` 把时间顺序放在前面：第一滴雨还没有碰到地面，人们却可能已经闻到了雨的气味。`the first drop reaches the ground` 不是说雨已经下了一阵，而是强调第一滴落地之前这个很早的时刻。整句是在建立一个反差：气味先到，雨滴还没到。

再听一遍，抓住 `before` 带出的时间关系：**People often notice the smell of rain before the first drop reaches the ground.**

**That familiar scent has a name: petrichor.** `that familiar scent` 指的就是上一句说的、我们熟悉的雨的气味。`has a name` 是“有一个名称”，冒号后面直接给出名字：`petrichor`，通常译作“雨后土腥味”或“雨后气味”。这里不是说所有人都必须马上记住拼写，先能认出这个词，并知道它在文章里指这种雨的气味就够了。

**The word joins Greek roots for stone and a fluid once linked to the earth.** 这句话解释 `petrichor` 这个词的构成。`joins ... roots` 可以理解为“把几个词根组合在一起”；`roots for stone` 是表示“石头”的词根，`a fluid once linked to the earth` 是曾经和土地联系在一起的一种液体。`once linked to` 表示过去曾经被联系起来。作者先给现象命名，再稍微打开这个名字的来源，让它带有一种来自地面的感觉。

**It describes a real mixture rather than one single perfume.** `It` 指 `petrichor`，也就是这种雨的气味。`rather than` 是“而不是”，是本句的关键：它描述的是一种真实的混合物，而不是一瓶叫作“雨”的单一香水。`one single` 还加强了“一个、单独的”意味。现在第一段的逻辑就完整了：我们先闻到现象，给它一个名字，再知道它不是一种单独物质。

接着读第二段。**It appears when dry soil, plants, and tiny organisms release compounds into the air.** `It` 仍然指前面的这种气味。`appears when` 表示“在……发生时出现”；真正释放东西的是 `dry soil, plants, and tiny organisms`，也就是干燥的土壤、植物和微小生物。`release compounds into the air` 是“把化合物释放到空气中”。这里先列出来源，说明气味来自许多成分进入空气。

**Rain carries those compounds upward as small droplets hit the ground.** `those compounds` 指上一句提到的化合物。`carry ... upward` 是“把……带向上方”；`as` 在这里表示“当……时”。小雨滴撞击地面时，雨把这些成分带向上方。注意作者不是说雨水自己制造了气味，而是在说明雨滴怎样提供一条路径。

**The droplets can burst and make a fine spray.** `droplets` 是小水滴，`burst` 是破裂、爆开，`a fine spray` 是细小的喷雾。句子很短，但它补上了过程中的关键动作：雨滴落地后可能破裂，形成细喷雾。

**That spray gives the scent a route into the air around you.** `That spray` 指刚才的细喷雾，`gives ... a route` 是“给……提供一条路线”。`the air around you` 是你周围的空气。也就是说，喷雾让地面上的成分有机会进入你正在呼吸的空气。第二段要抓住的不是四句分散的事实，而是一条过程链：成分来自土地和植物，雨滴撞地，形成喷雾，气味因此进入空气。

下面进入第三段，文章从整体过程缩小到一个具体成分。**One important compound is made by soil bacteria.** `one important compound` 表示“其中一种重要化合物”，`is made by` 是“由……产生”，`soil bacteria` 是土壤细菌。作者没有说这就是全部气味，而是先挑出一个重要例子。

**It is called geosmin.** `It` 指上一句的那种化合物，`is called` 是“被称为”。这个名字 `geosmin` 先需要识别，不必现在背下拼写。把它和“土壤细菌产生的一种重要成分”对应起来，就能继续读下去。

**Humans are unusually sensitive to it, even at very low levels.** `sensitive to` 是“对……敏感”，`it` 指 `geosmin`。`even at very low levels` 表示“即使浓度非常低也如此”。这句话的重点是：人类鼻子不需要等到这种成分很多，少量时也可能察觉到。

**That sensitivity may explain why a light shower can seem surprisingly noticeable.** `That sensitivity` 指前一句说的人类敏感性；`may explain why` 表示“可能解释了为什么”，语气保留余地，不是绝对断言。`a light shower` 是一场小阵雨，`seem surprisingly noticeable` 是“显得出人意料地明显”。因为我们对 `geosmin` 很敏感，所以少量成分也可能让一场小雨闻起来很突出。重听时注意 `may`：作者是在提出可能解释，而不是把因果说死。

第四段继续补充另一个来源。**Another part comes from oils that plants leave on dry surfaces.** `Another part` 表示“另一部分”，说明雨的气味还有别的来源。植物留在干燥表面上的油，也会成为这种气味的一部分。`that plants leave on dry surfaces` 修饰 `oils`，说明这些油是植物留下的。

**Those oils build up during dry weather.** `Those oils` 指上一句的植物油，`build up` 是逐渐积累。天气干燥时，这些油会慢慢积在表面上。这里的 `during` 把积累放在一段持续的干燥天气中。

**After a long dry spell, the first rain can release more of them at once.** `a long dry spell` 是一段长时间的干旱或少雨期；`more of them` 指更多的植物油；`at once` 是“一下子、同时”。久旱之后，第一场雨可能一次释放出更多积累的植物油。这个句子的时间结构很重要：先有很长的干燥，之后第一场雨带来集中释放。

**A sudden summer shower may therefore smell stronger than steady rain.** `therefore` 表示“因此”，把前面的积累和后面的结果连起来。突然的夏季阵雨，可能比持续的降雨闻起来更强。`stronger than` 是比较，比较的是气味强弱，不是雨本身的大小。作者仍然用 `may`，保持科学说明中的谨慎。

第五段加入地点和天气条件。**The smell is not exactly the same in every place.** `not exactly the same` 是“不完全相同”，不是说每个地方都完全不同。`in every place` 把范围扩展到不同地点。到这里，文章提醒我们：雨的气味没有一个处处一样的固定配方。

**Temperature changes how quickly compounds move through the air.** `how quickly` 引出“速度有多快”；温度会改变化合物在空气中移动的速度。这里的 `changes how...` 是“改变……的方式或程度”，不是简单说温度让气味变好或变坏。

**Wind decides whether they reach you or drift away.** `they` 指前文的化合物；`whether ... or ...` 是“是……还是……”。风决定这些成分会到达你这里，还是飘走。`reach you` 和 `drift away` 形成清楚对比：同样的地面释放了成分，风向不同，你闻到的结果也可能不同。

**Soil and local plants add their own small signature.** `local plants` 是当地植物，`their own small signature` 是它们各自留下的一点“小签名”。这里的 `signature` 不是字面签名，而是能够辨认出来源的独特特征。土壤和当地植物共同给气味加上地方差异。

最后一段回到开头。**So the next time rain seems to have a smell, you are noticing a small weather story.** `the next time` 把文章带回未来的生活场景；`seems to have` 不是否认气味，而是保留“看起来、感觉上”的表达。你闻到的，其实是一段小小的天气故事：不同成分、雨滴和空气一起完成了这个结果。

**The air is carrying evidence of a dry landscape meeting water again.** `carry evidence of` 是“带着……的证据”；`a dry landscape meeting water again` 把干燥的土地重新遇到水写成一个画面。空气带来的不只是气味，也像带来了土地重新遇到水的证据。

**It is a sensory clue about what was on the ground before the rain began.** `It` 指前面的这种气味；`a sensory clue` 是“感官线索”。`what was on the ground before the rain began` 是一个名词性从句，表示“下雨前地面上有什么”。气味让我们通过鼻子得到线索，回头感知雨开始前地面的状态。

**That is why the same weather can feel different in two nearby places.** `That is why` 表示“这就是为什么”，把全文的解释收回来：同样的天气，在相邻的两个地方也可能感觉不同，因为真正参与气味形成的土壤、植物、温度和风并不完全相同。读完这句，标题的问题也得到回答：雨的气味是许多地面和空气条件共同形成的故事，而不是雨水自身的一种固定香味。

现在把最后四句连起来听，抓住它们怎样从“天气故事”回到“地点差异”：**So the next time rain seems to have a smell, you are noticing a small weather story. The air is carrying evidence of a dry landscape meeting water again. It is a sensory clue about what was on the ground before the rain began. That is why the same weather can feel different in two nearby places.**

这篇文章从一个熟悉的气味开始，带我们看见了它背后的成分、路径和地点差异。下次闻到雨的气味时，你可以先记住：你闻到的不是一个孤立的结果，而是土地、植物、细菌、雨滴和空气共同留下的线索。
