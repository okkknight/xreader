有些事情我们每天都遇到，却很少停下来问它为什么会发生。雨的气味就是这样一个小问题：它还没落下，我们有时已经闻到了。

# Why Does Rain Have a Smell?

为什么雨会有气味？标题把问题留给了全文。读到最后，答案会从“雨水本身”转向土地、植物、微生物和空气之间发生的过程。

**People often notice the smell of rain before the first drop reaches the ground.** `before` 把时间关系说得很清楚：第一滴雨还没有落地，人们已经可能察觉到气味。先别逐词翻译，只听这个反差：**People often notice the smell of rain before the first drop reaches the ground.**

**That familiar scent has a name: petrichor.** `That` 接住前面的雨的气味，`petrichor` 是它的名称。先能认出这个词，并知道它在文中指什么，就足够继续了。

**The word joins Greek roots for stone and a fluid once linked to the earth.** 这句把词源的画面打开：`petrichor` 把“石头”和一种曾与土地联系在一起的液体放进同一个词里。

**It describes a real mixture rather than one single perfume.** `It` 指这个名称所描述的气味，`rather than` 则划出关键对比：这是真实成分的混合，不是一瓶单独的“雨香水”。第一段先命名，再拆掉一个误解。

文章接着追踪气味怎样进入空气。**It appears when dry soil, plants, and tiny organisms release compounds into the air.** `It` 仍然指这种气味；干燥土壤、植物和微小生物，把化合物释放进空气。三个来源一起构成起点。

**Rain carries those compounds upward as small droplets hit the ground.** `those compounds` 承接上一句；`as` 表示雨滴撞地的同时，雨把这些成分带向上方。雨不是凭空制造气味，而是给它提供了移动的路径。

**The droplets can burst and make a fine spray.** 雨滴可能破裂，形成细喷雾。句子很短，但这是过程中的关键动作。

**That spray gives the scent a route into the air around you.** `That spray` 把这个动作收回来：喷雾让地面成分进入你周围的空气。把四句连起来，听一条简单的链：来源、撞击、喷雾、到达鼻子附近。

第三段把镜头推进到一个具体成分。**One important compound is made by soil bacteria.** 这是“其中一种重要成分”，不是全部答案；它由土壤细菌产生。

**It is called geosmin.** `It` 指这个成分，`is called` 是命名结构。`geosmin` 先作为一个识别词放在这里，不需要现在主动背下来。

**Humans are unusually sensitive to it, even at very low levels.** `sensitive to` 是“对……敏感”，`it` 仍指 geosmin。即使浓度很低，人类也可能察觉到它。

**That sensitivity may explain why a light shower can seem surprisingly noticeable.** `That sensitivity` 接住上句，`may explain why` 保留了可能性：小雨之所以也可能闻起来明显，原因之一是人类对这种成分很敏感。重听时留意 `may`，作者没有把解释说成绝对规律。

另一条来源来自植物。**Another part comes from oils that plants leave on dry surfaces.** `Another part` 告诉我们，petrichor 还有另一部分；植物留在干燥表面的油也参与其中。

**Those oils build up during dry weather.** `build up` 是逐渐积累。干燥持续得越久，表面留下的东西越多。

**After a long dry spell, the first rain can release more of them at once.** `After` 先放出久旱这个背景，`more of them` 指更多的植物油，`at once` 是一下子释放。先有长时间干燥，再有第一场雨集中带出成分。

**A sudden summer shower may therefore smell stronger than steady rain.** `therefore` 把积累推向结果：突然的夏季阵雨可能比持续的雨闻起来更强。这里的 `may` 又让语气保持谨慎。

现在文章从来源转向地点差异。**The smell is not exactly the same in every place.** `not exactly the same` 是“不完全相同”，雨的气味没有一张固定配方。

**Temperature changes how quickly compounds move through the air.** 温度会改变这些化合物在空气中移动的速度。`how quickly` 让我们关注移动快慢。

**Wind decides whether they reach you or drift away.** `they` 指这些化合物；`whether ... or ...` 给出两种结果：到达你这里，或者飘走。地面释放了成分，不代表你一定闻得到。

**Soil and local plants add their own small signature.** `signature` 在这里是地方特征。土壤和当地植物，给同一种天气加上不同的“小签名”。这一段的重心是地点和空气条件共同决定气味。

最后回到标题的问题。**So the next time rain seems to have a smell, you are noticing a small weather story.** `the next time` 把解释带回日常经验；你注意到的不是孤立的气味，而是一段天气故事。

**The air is carrying evidence of a dry landscape meeting water again.** `evidence of` 是“……的证据”。空气带来的，像是干燥土地重新遇到水的证据。

**It is a sensory clue about what was on the ground before the rain began.** `It` 指这种气味，`what was on the ground` 说明它提供了关于下雨前地面状态的感官线索。

**That is why the same weather can feel different in two nearby places.** `That is why` 把全文收回来：相邻地点的土壤、植物、温度和风不同，所以同样的天气也可能闻起来不同。最后四句连着听，注意文章如何从气味回到地面：**So the next time rain seems to have a smell, you are noticing a small weather story. The air is carrying evidence of a dry landscape meeting water again. It is a sensory clue about what was on the ground before the rain began. That is why the same weather can feel different in two nearby places.**

文章沿着一条过程读完了：成分从哪里来，雨滴怎样把它们带进空气，为什么少量 geosmin 也可能明显，以及为什么不同地点的雨有自己的气味。这样回到生活里的雨，标题的问题就不只是一个术语，而是有了具体画面。

好，这篇文章我们已经从标题读到了最后一句。下次再闻到雨的气味时，不必急着把所有术语都背下来；能认出这是一段土地、植物和水重新相遇的天气故事，就已经把文章真正带走了。
